Place all the contents into the scripts folder.

DO NOT REPACK THIS CONTENT AND CLAIM AS YOUR OWN. IF YOU DO, THERE WILL BE TROUBLE.