using System;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;

public class RandomMadness : Script
{
    private bool isActive = false;
    private int timerSeconds = 30;
    private int lastTickTime = 0;

    private bool trafficJumpActive = false;
    private int trafficJumpEndTime = 0;

    private bool npcsMadActive = false;
    private int npcsMadEndTime = 0;

    private Random random = new Random();

    public RandomMadness()
    {
        Tick += OnTick;
        KeyDown += OnKeyDown;
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.OemPeriod)
        {
            isActive = !isActive;

            if (isActive)
            {
                UI.Notify("~g~Random Madness Activated");
                timerSeconds = 30;
                lastTickTime = Game.GameTime;
            }
            else
            {
                UI.Notify("~r~Random Madness Deactivated");
                trafficJumpActive = false;
                npcsMadActive = false;
            }
        }
    }

    private void OnTick(object sender, EventArgs e)
    {
        if (!isActive) return;

        // Display timer using built-in v2 UI method
        UI.ShowSubtitle("Next Effect: " + timerSeconds + "s", 1000);

        if (Game.GameTime - lastTickTime >= 1000)
        {
            lastTickTime = Game.GameTime;
            timerSeconds--;

            if (timerSeconds <= 0)
            {
                TriggerRandomEffect();
                timerSeconds = 30;
            }
        }

        HandleActiveEffects();
    }

    private void TriggerRandomEffect()
    {
        try
        {
            int effectIndex = random.Next(0, 14);

            switch (effectIndex)
            {
                case 0: EffectMonkeyRaid(); break;
                case 1: EffectTrafficJump(); break;
                case 2: EffectGiveAllWeapons(); break;
                case 3: EffectRandomOutfit(); break;
                case 4: EffectAllNpcsMad(); break;
                case 5: EffectRemoveNpcWeapons(); break;
                case 6: EffectUpgradeCar(); break;
                case 7: EffectDeleteCar(); break;
                case 8: EffectSnowyWeather(); break;
                case 9: EffectRemoveWantedLevel(); break;
                case 10: EffectFlingPlayer(); break;
                case 11: EffectSpawnLester(); break;
                case 12: EffectSpawnAdder(); break;
                case 13: EffectCayoHeistCompleted(); break;
            }
        }
        catch (Exception ex)
        {
            UI.Notify("~r~Effect Error: " + ex.Message);
        }
    }

    // --- EFFECTS ---

    private void EffectMonkeyRaid()
    {
        UI.Notify("~r~Effect: Monkey Raid!");
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        PedHash monkeyHash = PedHash.Chimp;

        for (int i = 0; i < 4; i++)
        {
            Vector3 spawnPos = player.Position + player.ForwardVector * 3.0f + new Vector3(random.Next(-3, 3), random.Next(-3, 3), 0);
            Ped monkey = World.CreatePed(monkeyHash, spawnPos);

            if (monkey != null && monkey.Exists())
            {
                monkey.Weapons.Give(WeaponHash.Crowbar, 1, true, true);
                monkey.BlockPermanentEvents = true;
                monkey.Task.FightAgainst(player);
            }
        }
    }

    private void EffectTrafficJump()
    {
        UI.Notify("~y~Effect: Traffic Jump!");
        trafficJumpActive = true;
        trafficJumpEndTime = Game.GameTime + 15000;
    }

    private void EffectGiveAllWeapons()
    {
        UI.Notify("~g~Effect: All Weapons & Ammo Granted!");
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        foreach (WeaponHash weapon in Enum.GetValues(typeof(WeaponHash)))
        {
            if (weapon == WeaponHash.Unarmed || (int)weapon == 0) continue;

            try
            {
                if (!player.Weapons.HasWeapon(weapon))
                {
                    player.Weapons.Give(weapon, 9999, false, false);
                }
                else if (player.Weapons[weapon] != null)
                {
                    player.Weapons[weapon].Ammo = player.Weapons[weapon].MaxAmmo;
                }
            }
            catch
            {
                // Safely skip any invalid enum values
            }
        }
    }

    private void EffectRandomOutfit()
    {
        UI.Notify("~purple~Effect: Random Outfit!");
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        for (int component = 0; component < 12; component++)
        {
            int maxVariations = Function.Call<int>(Hash.GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS, player.Handle, component);
            if (maxVariations > 0)
            {
                int randomDrawable = random.Next(0, maxVariations);
                Function.Call(Hash.SET_PED_COMPONENT_VARIATION, player.Handle, component, randomDrawable, 0, 0);
            }
        }
    }

    private void EffectAllNpcsMad()
    {
        UI.Notify("~r~Effect: All NPCs Angry!");
        npcsMadActive = true;
        npcsMadEndTime = Game.GameTime + 15000;
    }

    private void EffectRemoveNpcWeapons()
    {
        UI.Notify("~b~Effect: Disarmed All Nearby NPCs!");
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        Ped[] nearbyPeds = World.GetNearbyPeds(player.Position, 100.0f);

        foreach (Ped ped in nearbyPeds)
        {
            if (ped != null && ped.Exists() && ped != player)
            {
                ped.Weapons.RemoveAll();
            }
        }
    }

    private void EffectUpgradeCar()
    {
        Ped player = Game.Player.Character;
        if (player != null && player.Exists() && player.IsInVehicle())
        {
            Vehicle veh = player.CurrentVehicle;
            if (veh != null && veh.Exists())
            {
                veh.Repair();
                veh.EngineHealth = 1000.0f;
                UI.Notify("~g~Effect: Vehicle Repaired & Maxed!");
                return;
            }
        }
        UI.Notify("~y~Effect: Upgrade Car (Not in Vehicle!)");
    }

    private void EffectDeleteCar()
    {
        Ped player = Game.Player.Character;
        if (player != null && player.Exists() && player.IsInVehicle())
        {
            Vehicle veh = player.CurrentVehicle;
            if (veh != null && veh.Exists())
            {
                veh.Delete();
                UI.Notify("~r~Effect: Vehicle Deleted!");
                return;
            }
        }
        UI.Notify("~y~Effect: Delete Car (Not in Vehicle!)");
    }

    private void EffectSnowyWeather()
    {
        World.Weather = Weather.Christmas;
        UI.Notify("~white~Effect: Snowy Weather!");
    }

    private void EffectRemoveWantedLevel()
    {
        Game.Player.WantedLevel = 0;
        UI.Notify("~blue~Effect: Wanted Level Cleared!");
    }

    private void EffectFlingPlayer()
    {
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        if (player.IsInVehicle())
        {
            Vehicle veh = player.CurrentVehicle;
            if (veh != null && veh.Exists())
            {
                veh.ApplyForce(new Vector3(0, 0, 30.0f) + veh.ForwardVector * 20.0f);
            }
        }
        else
        {
            player.ApplyForce(new Vector3(0, 0, 30.0f) + player.ForwardVector * 20.0f);
        }
        UI.Notify("~orange~Effect: Player Flung!");
    }

    private void EffectSpawnLester()
    {
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        Vector3 spawnPos = player.Position + player.ForwardVector * 2.5f;
        World.CreatePed(PedHash.LesterCrest, spawnPos);
        UI.Notify("~yellow~Effect: Lester Spawned!");
    }

    private void EffectSpawnAdder()
    {
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        Vector3 spawnPos = player.Position + player.ForwardVector * 5.0f;
        Vehicle adder = World.CreateVehicle(VehicleHash.Adder, spawnPos, player.Heading);

        if (adder != null && adder.Exists())
        {
            UI.Notify("~purple~Effect: Adder Spawned!");
        }
    }

    private void EffectCayoHeistCompleted()
    {
        Game.Player.Money += 2000000;
        UI.Notify("~g~Effect: Cayo Heist Completed! +$2,000,000");
    }

    // --- CONTINUOUS TIMED EFFECTS LOGIC ---

    private void HandleActiveEffects()
    {
        Ped player = Game.Player.Character;
        if (player == null || !player.Exists()) return;

        if (trafficJumpActive)
        {
            if (Game.GameTime < trafficJumpEndTime)
            {
                Vehicle[] nearbyVehicles = World.GetNearbyVehicles(player.Position, 150.0f);
                foreach (Vehicle veh in nearbyVehicles)
                {
                    if (veh != null && veh.Exists() && veh.IsOnAllWheels)
                    {
                        veh.ApplyForce(new Vector3(0, 0, 7.0f));
                    }
                }
            }
            else
            {
                trafficJumpActive = false;
            }
        }

        if (npcsMadActive)
        {
            if (Game.GameTime < npcsMadEndTime)
            {
                Ped[] nearbyPeds = World.GetNearbyPeds(player.Position, 50.0f);

                foreach (Ped ped in nearbyPeds)
                {
                    if (ped != null && ped.Exists() && ped != player && ped.IsAlive)
                    {
                        ped.BlockPermanentEvents = true;
                        if (!ped.IsInCombat)
                        {
                            ped.Task.FightAgainst(player);
                        }
                    }
                }
            }
            else
            {
                npcsMadActive = false;
            }
        }
    }
}