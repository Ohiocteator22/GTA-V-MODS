Rainbomizer: V

A modification for Grand Theft Auto V that randomizes various aspects of the game from vehicles and sounds to missions and weapons.

#######################################################
## Features

- Vehicles Appearance Randomizer: Randomizes vehicle colours and upgrades like license plates, paintjobs, armour, etc.
- Parked Car Randomizer: Randomizes vehicles parked around the map including boats and planes.
- Clothes Randomizer: Randomizes the clothes and props the peds spawn with.
- Traffic Randomizer - Randomizes cars that spawn in traffic. 
- Mission Vehicle Randomizer - Randomizes vehicles you are given in missions, making sure that the vehicle you're given is usable for that mission.
- Colour Randomizer - Randomizes colours of various in-game elements, including cars, the HUD, and more. 
- Mission Randomizer - Randomizes order of missions in-game. Upon completion of a mission, the game progresses as if you completed the original mission.
- Weapon Randomizer - Randomizes weapons given to the enemies.
- Sounds Randomizer - Randomizes dialogue and sound effects played in-game.
- Cutscene Randomizer - Randomizes models used in motion-captured cutscenes.
- Ped Randomizer - Randomizes all ambient, mission, and cutscene peds.
- Player Randomizer - Randomizes the player model into a different ped model.
- Player Special Ability Randomizer - With Player Randomizer enabled, this feature randomizes the player's special ability.
- Timecycle and Weather Randomizer - Randomizes the look of the game by randomizing weather elements and sky colour.
- Handling Randomizer - Randomizes the handling of all vehicles.
- Weapon Stats Randomizer - Randomizes weapon stats such as fire rate, range, etc. of all weapons.
- Dispatch Randomizer - Randomizes all dispatched police cars, ambulances, helicopters, and boats.
- Light Randomizer - Randomizes all light colours in the game.
- Respawn Randomizer - Randomizes where you respawn.
- Switch Scene Randomizer - Randomizes the scene played when you switch to a different character.


#######################################################
## Installation

Rainbomizer requires an ASI-Loader to function. It works with all versions of the game. Additionally, you require ScriptHook for certain features.

1. Install ScriptHook (includes an ASI Loader) from http://www.dev-c.com/gtav/scripthookv
2. Extract the archive to the root directory of GTA V. 

#######################################################
## Configuration

If you wish to change any of the mod's functionalities, for example to disable a specific randomizer, a configuration file (config.toml) has been provided with the mod. The config file is located in the rainbomizer folder in the game's root directory.

The default configuration file is in the main repository, config.toml, and is automatically created by the mod if it doesn't exist in the rainbomizer folder using pre-determined default values.

It can be opened and modified with a text editing program such as Notepad++. Any aspect of the mod can be modified to your liking using this file - if you make changes while the game is running, the game must be restarted for these to take effect.

- To enable or disable a certain randomizer, set the corresponding value to "true" or "false" from the list of randomizers at the top of the file.   
- To configure a certain randomizer, find its specific section in the file by searching for its name. If there isn't a specific section, the randomizer doesn't offer further customization. More information about how to configure specific randomizers is provided in the default config file.

#######################################################
## Credits

#### Lead Developers

- Parik - Creation and implementation of the ASI.

#### Major Contributors

- Fryterp23 - Assisting with creation of external files and extensive testing.
- 123robot - Creation of external files, testing, and support with debugging.

#### Beta Testers

- Gibstack
- Hugo_One
- mo_xi
- SpeedyFolf
