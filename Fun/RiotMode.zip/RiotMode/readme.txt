** First time use **
- Place RiotMode.asi and RiotMode_config.txt in your GTA V installation directory, alongside dinput8.dll and ScriptHookV.dll.
- Edit RiotMode_config.txt to your liking. Format is important! Please lookup JSON format if you have any problems.

** Usage instructions **
- F7 to toggle (default). The config file is also reloaded whenever the mod is toggled.

** Troubleshooting **
- If the game is crashing, try lowering the number of rioters spawned in the config file, and ensure you have the latest version of Script Hook V
- If Riot Mode is not loading when pressing the enable key, ensure you have the latest version of Script Hook V
- If you are still experiencing issues, please post your Script Hook V log (found in the GTA V directory) along with your Windows version and any additional information here:
http://gtaforums.com/topic/790606-vrel-ped-riot-mode/

** Disclaimer **
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.