# Hoodcore / IdentiSwitch / Action Gear / Immersify II — license system rollout

All four mods now use a new license system. **To keep playing after you update, download your license file once from kassiter-mods.com/account and drop it into your `scripts/` folder.**

## What to do

1. Sign in with Patreon at **kassiter-mods.com/account**
2. Click **Download License** — saves `kassiter.lic`
3. Drop `kassiter.lic` into `Grand Theft Auto V/scripts/`
4. Update the mod DLLs as usual
5. Launch the game

If you update the mods without the license file, you'll see "License file missing — download from kassiter-mods.com/account" in-game.

## What changed

- Replaced the old email-based authentication with a signed license file tied to your Patreon account.
- License expires every 14 days but auto-renews on each play session with internet — most patrons will never see it expire.
- Works fully offline for up to 21 days from your last online play, then asks you to reconnect once to refresh.
- Patron status lapses and comebacks are handled — if you cancel and re-pledge later, your license still works.

